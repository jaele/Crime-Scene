#include <iostream>
#include "Character.hpp"

using namespace std;



string Character::getcharacterName()
{
	return characterName;
}



void Character::setdisplayName(string displayName)
{
	this->displayName = displayName;
}

string Character::getdisplayName()
{
	return displayName;
}




void Character::setpreviousLocation(string previousLocation)
{
	this->previousLocation = previousLocation;
}


string Character::getpreviousLocation()
{

	return previousLocation;
}


string Character::getPocket1()
{
	return pocket1;
}


string Character::getPocket2()
{
	return pocket2;
}

string Character::getPocket3()
{
	return pocket3;
}

string Character::getPocket4()
{
	return pocket4;
}

string Character::getPocket5()
{
	return pocket5;
}

string Character::getPocket6()
{
	return pocket6;
}

string Character::getPocket7()
{
	return pocket7;
}

string Character::getPocket8()
{
	return pocket8;
}


string Character::getPocket9()
{
	return pocket9;
}


string Character::getPocket10()
{
	return pocket10;
}


string Character::getPocket11()
{
	return pocket11;
}
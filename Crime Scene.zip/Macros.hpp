// macros
int verifyInput();
void paused();
void pause2();
void clrf();